package com.cws.dialogs;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import javax.swing.*;
import java.awt.event.*;


public class RootDialog extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField propertyName;
    private JTextArea propertyValue;
    private JTextField textField1;

    public RootDialog() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

// call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

// call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onOK() {
        Project current = ProjectManager.getInstance().getOpenProjects()[0];
        String propPath=current.getBasePath()+"/myprops.properties";
        propertyName.setText(propPath);
        PropertiesConfiguration configuration = null;
        try {
            configuration = new PropertiesConfiguration(propPath);
        } catch (ConfigurationException e) {
            propertyValue.setText(e.toString());
            e.printStackTrace();
        }
        configuration.setProperty("abc","cde");
        configuration.setProperty("bcd","edf");

        try {
            configuration.save();
        } catch (ConfigurationException e) {
            propertyValue.setText(e.toString());
        }

        System.out.println(current.getBaseDir());
        textField1.setText(current.getBasePath()+"   "+current.getBaseDir().toString());
    }

    private void onCancel() {
// add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        RootDialog dialog = new RootDialog();
        dialog.pack();
        dialog.setVisible(true);
        //System.exit(0);
    }
}
