package com.cws.applicationComponent;

import com.cws.action.DialogLaunchAction;
import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.openapi.components.ApplicationComponent;
import org.jetbrains.annotations.NotNull;

/**
 * Created by Sarthak on 17-02-2017.
 */
public class PropertyManagerAppComponent implements ApplicationComponent {
    @Override
    public void initComponent() {
        ActionManager actionManager = ActionManager.getInstance();
        DialogLaunchAction action = new DialogLaunchAction();

        actionManager.registerAction("Dialog Launch Action",action);

        DefaultActionGroup editM = (DefaultActionGroup) actionManager.getAction("EditMenu");

        editM.addSeparator();
        editM.add(action);
    }

    @Override
    public void disposeComponent() {

    }

    @NotNull
    @Override
    public String getComponentName() {
        return "Property Manager";
    }
}
