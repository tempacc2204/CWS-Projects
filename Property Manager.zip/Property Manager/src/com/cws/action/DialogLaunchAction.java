package com.cws.action;

import com.cws.dialogs.RootDialog;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;

/**
 * Created by Sarthak on 17-02-2017.
 */
public class DialogLaunchAction extends AnAction {

    public DialogLaunchAction(){
        super("Add/Update Property");
    }

    @Override
    public void actionPerformed(AnActionEvent anActionEvent) {
        RootDialog.main(new String[0]);
    }
}
